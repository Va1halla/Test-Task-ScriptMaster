Action()
{

	lr_start_transaction("Opening");

	web_url("index.htm", 
		"URL={Protocol}://{Host}:{Port}/{Path}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	lr_end_transaction("Opening", LR_AUTO);


	lr_think_time(15);
	
	lr_start_transaction("Auth");

	web_submit_form("login.pl", 
		"Snapshot=t2.inf", 
		ITEMDATA, 
		"Name=username", "Value={Login}", ENDITEM, 
		"Name=password", "Value={Pass}", ENDITEM, 
		"Name=login.x", "Value=71", ENDITEM, 
		"Name=login.y", "Value=16", ENDITEM, 
		LAST);
	lr_end_transaction("Auth", LR_AUTO);

	lr_start_transaction("SearchFlight");

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t3.inf",
		LAST);
	lr_end_transaction("SearchFlight", LR_AUTO);


	web_set_sockets_option("SSL_VERSION", "2&3");
	
	lr_start_transaction("DataInput");

	web_submit_form("reservations.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=09/28/2019", ENDITEM, 
		"Name=arrive", "Value=London", ENDITEM, 
		"Name=returnDate", "Value=09/29/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=on", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=findFlights.x", "Value=57", ENDITEM, 
		"Name=findFlights.y", "Value=8", ENDITEM, 
		LAST);
	lr_end_transaction("DataInput", LR_AUTO);


	lr_think_time(16);
	
	lr_start_transaction("SelectPlane");

	web_submit_data("reservations.pl_2", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=020;491;09/28/2019", ENDITEM, 
		"Name=returnFlight", "Value=203;401;09/29/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=reserveFlights.x", "Value=65", ENDITEM, 
		"Name=reserveFlights.y", "Value=2", ENDITEM,
		LAST);
	lr_end_transaction("SelectPlane", LR_AUTO);

	lr_think_time(31);
	lr_start_transaction("Ending");

	web_submit_form("reservations.pl_3", 
		"Snapshot=t7.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=Wall Street", ENDITEM, 
		"Name=address2", "Value=New York", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=1122334455667788", ENDITEM, 
		"Name=expDate", "Value=11.21", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		"Name=buyFlights.x", "Value=69", ENDITEM, 
		"Name=buyFlights.y", "Value=1", ENDITEM, 
		LAST);
	lr_end_transaction("Ending", LR_AUTO);


	return 0;
}